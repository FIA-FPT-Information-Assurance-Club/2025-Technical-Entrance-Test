#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

//------------------------Setup config (just ignore)---------------------
void kill_on_timeout(int sig) {
    if (sig == SIGALRM) {
        printf("[!] Anti DoS Signal. Patch me out for testing.");
        _exit(0);
    }
}

void ignore_me_init_signal() {
    signal(SIGALRM, kill_on_timeout);
    alarm(180);
}
//------------------------Setup config (just ignore)---------------------

//----------------------------------main------------------------------------
int main(){
	char buf[16];
	int v1 = 0;
	printf("Are you interested in joining FIA club (Yes or No only)> ");
	scanf("%s", buf);
	if(v1 != 0){
		printf("Your v1 var = %d", v1);
		system("/bin/sh");
	}
	else{
		printf("Hmmm.... Maybe try harder!!");
		exit(0);
	}
	return 0;
}
